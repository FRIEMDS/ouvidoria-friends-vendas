import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return Response.json({error:"Método não permitido"},{status:405,headers:cors});
 try{
  const form=await req.formData(), category=String(form.get("categoria")||""), message=String(form.get("mensagem")||"").trim();
  const allowed=["reclamacao","denuncia_vendedor","suspeita_golpe","elogio","avaliacao","sugestao"];
  if(!allowed.includes(category)||message.length<5||message.length>5000)return Response.json({error:"Confira os campos da manifestação."},{status:400,headers:cors});
  const db=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  let seller=null;const sellerId=String(form.get("vendedor_id")||"");
  if(sellerId){const {data}=await db.from("vendedores").select("id").eq("id",sellerId).eq("ativo",true).maybeSingle();if(!data)return Response.json({error:"Vendedor inválido."},{status:400,headers:cors});seller=data.id;}
  const anonymous=String(form.get("anonima"))==="true",rating=Number(form.get("nota")||5);
  const {data:row,error}=await db.from("manifestacoes").insert({categoria:category,vendedor_id:seller,nome_cliente:anonymous?null:String(form.get("nome_cliente")||"").slice(0,120),email_cliente:anonymous?null:String(form.get("email_cliente")||"").slice(0,254),anonima:anonymous,nota:Number.isInteger(rating)&&rating>=1&&rating<=5?rating:null,mensagem:message,status:"recebida"}).select("id,protocolo").single();
  if(error)throw error;
  let uploaded=0;
  for(const f of form.getAll("files").slice(0,3)){
   if(!(f instanceof File)||f.size>8*1024*1024)continue;
   if(!["image/jpeg","image/png","image/webp","video/mp4","application/pdf"].includes(f.type))continue;
   const ext=f.name.split(".").pop()?.toLowerCase()||"dat",path=`${row.id}/${crypto.randomUUID()}.${ext}`;
   const {error:uploadError}=await db.storage.from("manifestation-files").upload(path,f,{contentType:f.type,upsert:false});
   if(!uploadError)uploaded++;
  }
  return Response.json({protocolo:row.protocolo,anexos_recebidos:uploaded},{status:201,headers:cors});
 }catch(e){console.error(e);return Response.json({error:"Falha ao registrar. Tente novamente."},{status:500,headers:cors});}
});