# OUVIDORIA FRIENDS VENDAS

Base React/Vite para integrar ao projeto Supabase existente.

## Instalação local
1. Instale Node.js.
2. Extraia o ZIP e abra a pasta.
3. Execute `npm install`.
4. Copie `.env.example` para `.env` e preencha URL e chave publicável do projeto.
5. Execute `npm run dev`.

## Configuração obrigatória antes de produção
1. Criar bucket `manifestation-files` no Supabase Storage e deixá-lo **privado**.
2. Configurar `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` como secrets da Edge Function. Nunca colocar a service role no frontend.
3. Fazer deploy de `supabase/functions/submit-manifestation`.
4. Verificar que `public.is_admin()` retorna true somente para o UID do proprietário cadastrado em `admin_users`.
5. Confirmar que a tabela `manifestacoes` possui as 12 colunas já verificadas e `protocolo` tem default automático.
6. Configurar rate limiting e CAPTCHA/anti-spam no servidor.
7. Testar envio, protocolo, upload, login ADMIN e acesso negado a usuários comuns.

## Limitações atuais
- Não está publicado nem conectado ao seu projeto.
- Login usa e-mail/senha do Supabase Auth; ADMIN é o rótulo visual.
- A tela administrativa ainda não possui visualizador de anexos nem consulta de protocolo pelo cliente.
- O endpoint de envio usa service role somente no servidor, mas precisa de proteção anti-spam e testes antes de produção.
- O código pressupõe as colunas confirmadas da tabela `manifestacoes`: categoria, vendedor_id, nome_cliente, email_cliente, anonima, nota, mensagem, status e protocolo.
- Não compartilhe sua senha nem a chave service_role.
